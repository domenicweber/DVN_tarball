FactoryGirl.define do
  factory :authorization do
    name "MyString"
description "MyString"
  end

end
