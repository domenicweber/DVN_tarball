FactoryGirl.define do
  factory :user_authorization do
    user nil
authorization nil
  end

end
