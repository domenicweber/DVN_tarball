# require 'rails_helper'
#
# RSpec.describe "authorizations/show", type: :view do
#   before(:each) do
#     @authorization = assign(:authorization, Authorization.create!(
#       :name => "Name",
#       :description => "Description"
#     ))
#   end
#
#   it "renders attributes in <p>" do
#     render
#     expect(rendered).to match(/Name/)
#     expect(rendered).to match(/Description/)
#   end
# end
