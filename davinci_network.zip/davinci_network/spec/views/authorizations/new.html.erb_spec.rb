# require 'rails_helper'
#
# RSpec.describe "authorizations/new", type: :view do
#   before(:each) do
#     assign(:authorization, Authorization.new(
#       :name => "MyString",
#       :description => "MyString"
#     ))
#   end
#
#   it "renders new authorization form" do
#     render
#
#     assert_select "form[action=?][method=?]", authorizations_path, "post" do
#
#       assert_select "input#authorization_name[name=?]", "authorization[name]"
#
#       assert_select "input#authorization_description[name=?]", "authorization[description]"
#     end
#   end
# end
