# require 'rails_helper'
#
# RSpec.describe "authorizations/edit", type: :view do
#   before(:each) do
#     @authorization = assign(:authorization, Authorization.create!(
#       :name => "MyString",
#       :description => "MyString"
#     ))
#   end
#
#   it "renders the edit authorization form" do
#     render
#
#     assert_select "form[action=?][method=?]", authorization_path(@authorization), "post" do
#
#       assert_select "input#authorization_name[name=?]", "authorization[name]"
#
#       assert_select "input#authorization_description[name=?]", "authorization[description]"
#     end
#   end
# end
