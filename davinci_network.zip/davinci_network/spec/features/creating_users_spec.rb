require 'rails_helper'

feature 'Logged in Users' do
  current_user = false
  scenario 'allow a logged in user to claim a company' do
    @user = FactoryGirl.create(:user)
    @user2 = FactoryGirl.create(:user)
    @company = FactoryGirl.create(:company)

    visit login_path

    fill_in 'Email', with: @user.email
    fill_in 'Password', with: @user.password
    click_button 'Login'

    visit '/companies'
    click_link 'I Work Here'


    expect(page).to have_text("You now work at #{@company.name}.")

  end

  scenario 'allow a logged in user to create a new company and be associated with it' do
    @user = FactoryGirl.create(:user)
    @company = FactoryGirl.create(:company)

    visit login_path

    fill_in 'Email', with: @user.email
    fill_in 'Password', with: @user.password
    click_button 'Login'

    expect(page).to have_link('New Company')

    click_link 'New Company'

    fill_in 'Name', with: @company.name
    fill_in 'City', with: @company.city
    fill_in 'Company url', with: @company.company_url

    expect(page).to have_button('Create Company')
    click_button 'Create Company'

    expect(page).to have_text("Company was successfully created.")
    expect(page).to have_text("You now work at #{@company.name}.")

  end

  let(:user) { FactoryGirl.create(:user) }
  let(:user2) { FactoryGirl.create(:user) }
  let(:company) { FactoryGirl.create(:company) }
  let(:company2) { FactoryGirl.create(:company) }

  scenario 'allow users to view a list of users and their companies' do

    company.users << user
    company2.users << user2

    visit login_path

    fill_in 'Email', with: user.email
    fill_in 'Password', with: user.password
    click_button 'Login'

    expect(page).to have_link('Members')

    click_link 'Members'

    within("#user_#{user.id}") do
      expect(page).to have_text("#{user.first_name}")
      expect(page).to have_text("#{user.last_name}")
      expect(page).to have_text("#{company.name}")
    end

    within("#user_#{user2.id}") do
      expect(page).to have_text("#{user2.first_name}")
      expect(page).to have_text("#{user2.last_name}")
      expect(page).to have_text("#{company2.name}")
    end
  end
end
