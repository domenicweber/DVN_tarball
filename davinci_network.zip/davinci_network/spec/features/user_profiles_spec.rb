require 'rails_helper'

feature 'Logged in users can see profiles' do
  let(:user) { FactoryGirl.create(:user) }
  let(:user2) { FactoryGirl.create(:user) }
  let(:company) { FactoryGirl.create(:company) }
  let(:company2) { FactoryGirl.create(:company) }
  scenario "current user can see all members' profiles" do
    company.users << user
    company2.users << user2

    visit login_path

    fill_in 'Email', with: user.email
    fill_in 'Password', with: user.password
    click_button 'Login'

    click_link 'Members'

    expect(page).to have_link('View Profile')

    within("#user_#{user.id}") do
      click_link ('View Profile')
    end

    expect(page).to have_text("#{user.first_name}'s Profile")

    expect(page).to have_text("#{user.first_name}")
    expect(page).to have_text("#{user.last_name}")
    expect(page).to have_text("#{company.name}")
  end

# let(:user) { FactoryGirl.create(:user) }
# let(:company) { FactoryGirl.create(:company) }
# scenario "a logged in user can see their profile" do
#
#   company.users << user
#
#   visit login_path
#
#   fill_in 'Email', with: user.email
#   fill_in 'Password', with: user.password
#   click_button 'Login'
#
#   within('.dropdown-menu') do
#     click_link 'Profile'
#   end
#
#
#   expect(page).to have_text('My Profile')
#
#   expect(page).to have_text("#{user.first_name}")
#   expect(page).to have_text("#{user.last_name}")
#   expect(page).to have_text("#{company.name}")
# end
end