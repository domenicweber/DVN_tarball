require 'rails_helper'

feature 'User Authentication' do
  scenario 'allows a user to signup' do
    user = FactoryGirl.create(:user)

    visit '/'

    expect(page).to have_link('Signup')

    click_link 'Signup'

    fill_in 'First Name', with: user.first_name
    fill_in 'Last Name', with: user.last_name
    fill_in 'Email', with: user.email
    fill_in 'Password', with: user.password
    fill_in 'Password Confirmation', with: user.password_confirmation

    click_button 'Signup'

    expect(page).to have_text("Thank you for signing up #{user.first_name}")
    expect(page).to have_text("Signed in as #{user.email}")
    expect(ActionMailer::Base.deliveries).to have(1).email
  end

  scenario 'allows existing users to login' do
    user = FactoryGirl.create(:user)

    visit '/'

    expect(page).to have_link('Login')

    click_link 'Login'

    fill_in 'Email', with: user.email
    fill_in 'Password', with: user.password

    click_button 'Login'

    expect(page).to have_text("Welcome back #{user.first_name}")
    expect(page).to have_text("Signed in as #{user.email}")
  end

  scenario 'does not allow existing users to login with an invalid password' do
    user = FactoryGirl.create(:user)

    visit '/'

    expect(page).to have_link('Login')

    click_link 'Login'

    fill_in 'Email', with: user.email
    fill_in 'Password', with: 'INVALID_PASSWORD'

    click_button 'Login'

    expect(page).to have_text("Invalid email or password")
    expect(page).to_not have_text("Signed in as #{user.email}")
  end

  scenario 'allows a logged in user to logout' do
    user = FactoryGirl.create(:user)

    visit login_path

    fill_in 'Email', with: user.email
    fill_in 'Password', with: user.password

    click_button 'Login'

    expect(page).to have_text("Welcome back #{user.first_name}")
    expect(page).to have_text("Signed in as #{user.email}")

    expect(page).to have_link('Logout')

    click_link('Logout')

    expect(page).to have_text("#{user.email} has been logged out")
    expect(page).to_not have_text("Welcome back #{user.first_name}")
    expect(page).to_not have_text("Signed in as #{user.email}")
  end
end
