Rails.application.routes.draw do
  default_url_options host: 'http://davinci-network.herokuapp.com'

  root :to => "users#new"
  get 'login' => 'sessions#login'
  post 'login' => 'sessions#create'
  delete 'logout' => 'sessions#destroy'
  post 'authorizations' =>'admin/authorizations#create'
  patch 'authorization/:id' => 'admin/authorizations#update'
  put 'authorization/:id' => 'admin/authorizations#update'
  get 'company_search' => 'companies#index'
  get 'user_search' => 'users#index'

  resources :users,
    path_names: { new: 'signup' }

  namespace :admin do
    resources :authorizations
    resources :users

    # get 'functions' => 'admin_functions#admin'
    # get 'users' => 'users#index'
    # get ':user_id/student' => 'users#student'
  end

  resources :companies do
    member do
      get 'claim' => 'companies#claim'
      post 'claim' => 'companies#unclaim'
    end
  end


  get 'auth/:provider/callback' => 'sessions#oauth', as: 'auth_linkedin'
  get 'verification/:token' => 'users#verify', as: 'verify_email'
  # get 'auth/linkedin' => 'sessions#oauth'

end
