Rails.application.config.middleware.use OmniAuth::Builder do

  provider :linkedin, '78iwk7msq878vw', 'u7a4Tzb7Ob80s99T',
    :scope => 'r_basicprofile r_emailaddress', :fields => ["id", "email-address", "first-name", "last-name", "headline", "industry", "summary", "positions", "picture-url", "public-profile-url", "location", "connections"]

  # provider :linkedin, SERVICES['linkedin']['key'], SERVICES['linkedin']['secret']
  # provider :linkedin, "78iwk7msq878vw", "u7a4Tzb7Ob80s99T",
  #   :scope => 'r_fullprofile r_emailaddress r_network', :fields => ["id", "email-address", "first-name", "last-name", "headline", "industry", "picture-url", "public-profile-url", "location", "connections"]

end

# Rails.application.config.middleware.use OmniAuth::Builder do
#   provider :developer unless Rails.env.production?
#   provider :twitter, ENV['TWITTER_KEY'], ENV['TWITTER_SECRET']
# end
