# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)
#-----------------------
#   User Roles
Authorization.destroy_all
Authorization.create(id: 1, name: 'Admin', description: 'This gives the user authorization to perform backend functions.')
Authorization.create(id: 2, name: 'Student', description: 'This is a normal registered user, who can add and claim companies.')
Authorization.create(id: 3, name: 'Instructor', description: 'This is a normal registered user, who can adjust cohort and class.')
Authorization.create(id: 4, name: 'Mentor', description: 'This is a normal registered user, who use the calender.')
Authorization.create(id: 5, name: 'Board Member', description: 'This is a normal registered user, who has a public profile.')

#-----------------------
#  User-Authorizations
UserAuthorization.destroy_all
UserAuthorization.create(user_id: 1, authorization_id: 1)
UserAuthorization.create(user_id: 2, authorization_id: 1)
