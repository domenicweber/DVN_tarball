class AddQ3ToUsers < ActiveRecord::Migration
  def change
    add_column :users, :q3, :string
  end
end
