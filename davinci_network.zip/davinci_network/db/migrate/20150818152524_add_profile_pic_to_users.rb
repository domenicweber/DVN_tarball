class AddProfilePicToUsers < ActiveRecord::Migration
  def change
    add_column :users, :proflie_pic, :string
  end
end
