class AddQ2ToUsers < ActiveRecord::Migration
  def change
    add_column :users, :q2, :string
  end
end
