class AddQ1ToUsers < ActiveRecord::Migration
  def change
    add_column :users, :q1, :string
  end
end
