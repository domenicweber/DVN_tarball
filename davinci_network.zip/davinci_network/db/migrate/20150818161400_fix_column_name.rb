class FixColumnName < ActiveRecord::Migration
  def change
      rename_column :users, :proflie_pic, :image_url
  end
end
