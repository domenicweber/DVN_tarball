class AddPositionsToUsers < ActiveRecord::Migration
  def change
    add_column :users, :positions, :string
  end
end
