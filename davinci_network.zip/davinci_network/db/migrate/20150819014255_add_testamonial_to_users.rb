class AddTestamonialToUsers < ActiveRecord::Migration
  def change
    add_column :users, :testamonial, :string
  end
end
