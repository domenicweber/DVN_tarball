class Company < ActiveRecord::Base
  has_many :users

  def users_at_company
    users.map(&:first_name).join("<br>").html_safe
  end

end
