class LinkedInLocal < ActiveRecord::Base

  # LinkedIn.configure do |config|
  #   config.token = "78iwk7msq878vw"
  #   config.secret = "u7a4Tzb7Ob80s99T"
  # end

end
