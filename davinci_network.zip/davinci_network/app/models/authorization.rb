class Authorization < ActiveRecord::Base

  has_many :user_authorizations, :dependent => :destroy
  has_many :users, :through => :user_authorizations

  def self.admin
    where(name: 'Admin').first_or_create
  end

  def self.student
    where(name: 'Student').first_or_create
  end

  def self.instructor
    where(name: 'Instructor').first_or_create
  end

  def self.mentor
    where(name: 'Mentor').first_or_create
  end

  def self.board_member
    where(name: 'Board Member').first_or_create
  end

end
