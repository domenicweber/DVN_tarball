class User < ActiveRecord::Base
  has_secure_password(validations: false)
  belongs_to :company

validates_confirmation_of :password, if: ->(user) {
      !user.omniauth? && user.password.present?
    }
  validates_presence_of :password, if: ->(user) {
      !user.omniauth?
    }, on: :create
  validates_presence_of :password_confirmation, if: ->(user) {
      !user.omniauth? && user.password.present?
    }

  def authorization_names
    authorizations.map(&:name).join('/')
  end

  # puts name with company, so now we can call user.company_name
  delegate :name, to: :company, prefix: true, allow_nil: true
  # delegate :name, to: :authorization, prefix: true, allow_nil: true

  has_many :user_authorizations, dependent: :destroy
  has_many :authorizations, :through => :user_authorizations

  accepts_nested_attributes_for :authorizations

  def needs_verification!
    self.update_attributes!(
      token: SecureRandom.urlsafe_base64,
      verified_email: false
    )
    UserNotifier.signed_up(self).deliver_now
  end

  def verify!
    self.update_attributes!(
      token: nil,
      verified_email: true
    )
  end


  def make_student!
    unless student?
      authorizations << Authorization.student
    end
  end

  def last_name_first
    [self.last_name, self.first_name].join(', ')
  end

  def full_name
    [self.first_name, self.last_name].join(' ')
  end

  # User.authorizations.
  def admin?
    self.authorizations.include?(Authorization.admin)
  end

  def student?
    self.authorizations.include?(Authorization.student)
  end

  def instructor?
    self.authorizations.include?(Authorization.instructor)
  end

  def mentor?
    self.authorizations.include?(Authorization.mentor)
  end

  def board_member?
    self.authorizations.include?(Authorization.board_member)
  end

  def self.admins
    User.all.select{ |u| u.admin? }
  end

  def self.students
    User.all.select{ |u| u.student? }
  end

  def self.instructors
    User.all.select{ |u| u.instructor? }
  end

  def self.mentors
    User.all.select{ |u| u.mentor? }
  end

  def self.board_members
    User.all.select{ |u| u.board_member? }
  end


#   def send_confirmation!
#     UserNotifier.sign_up(self).deliver_now
# #    UserNotifier.sign_up_test(self, 'alkrauskopf@gmail.com').deliver_now
# #    UserNotifier.sign_up_test(self, 'hippy.berger@gmail.com').deliver_now
# #    UserNotifier.sign_up_test(self, 'andy.sowar@gmail.com').deliver_now
# #    UserNotifier.sign_up_test(self, 'Lamperta@gmail.com').deliver_now
#   end


end
