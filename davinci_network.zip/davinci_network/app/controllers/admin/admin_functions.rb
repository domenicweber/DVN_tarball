class Admin::AdminFunctionsController < Admin::AdminController
  before_action :current_user

  def admin

  end
end
