class Admin::AdminController < ApplicationController
  before_action :verify_admin_role

  private
  def verify_admin_role
    if current_user && current_user.admin?
    else
      flash[:error] = 'Not Authorized'
      redirect_to root_path
    end
  end
end
