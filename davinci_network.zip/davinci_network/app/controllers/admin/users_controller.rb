class Admin::UsersController < Admin::AdminController
  before_action :set_user, only: [:edit, :update, :destroy]


  # GET /users
  # GET /users.json
  def index
    @users = User.all
  end

  def update
    if @user.update(user_params)
      redirect_to edit_admin_user_path(@user), notice: "#{@user.last_name_first} has been successfully updated!"
    end
  end

  def edit

  end

  def destroy
    @user.destroy
    respond_to do |format|
      format.html { redirect_to admin_authorizations_path, notice: 'Authorization was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def admin
    @user.authorizations << Authorization.admin
    redirect_to root_path, notice: "#{@user.authorizations} is now an admin."
  end

  def student
    @user.authorizations << Authorization.student
    redirect_to root_path, notice: "#{@user.authorizations} is now a student."
  end

  def instructor
    @user.authorizations << Authorization.instructor
    redirect_to root_path, notice: "#{@user.authorizations} is now an instructor."
  end

  def mentor
    @user.authorizations << Authorization.mentor
    redirect_to root_path, notice: "#{@user.authorizations} is now a mentor."
  end

  def board_member
    @user.authorizations << Authorization.board_memeber
    redirect_to root_path, notice: "#{@user.authorizations} is now a board member."
  end


  private

  def set_user
    @user =User.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    nil
  end

  def user_params
    params.require(:user).permit(
      :first_name, :last_name, :email, :password, :password_confirmation, :authorization_ids => []
    )
  end

end
