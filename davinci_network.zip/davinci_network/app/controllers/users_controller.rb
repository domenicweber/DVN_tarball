class UsersController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy, :claim]
  before_action :verify_current_user, only: [:edit]

  helper_method :sort_column, :sort_direction

  def new
    @user = User.new
    if current_user
      redirect_to '/companies'
    end
  end

  def create
    @user = User.new(user_params)

    if @user.save
      @user.needs_verification!
      @user.make_student!
      session[:id] = @user.id
      redirect_to companies_path,
        notice: "Thank you for signing up #{@user.first_name}"
    else
      render :new
    end
  end

  def verify
    @user = User.where(token: params[:token]).first
    if @user
      @user.verify!
      redirect_to companies_path,
      notice: "Thanks for verifying your email"
    end

  end

  def index
    if params[:name].present?
      @users = User.joins(:company).where("companies.name = ?", params[:name])
    else
      @users = User.all
    end

    if sort_column == 'company_name'
      if sort_direction == 'asc'
        @users = @users.sort_by{|c| c.company_name || 'Unknown'}
      else
        @users = @users.sort_by{|c| c.company_name || 'Unknown'}.reverse
      end

    else
      @users = @users.order(sort_column + ' ' + sort_direction)
    end

    @all_company_names = Company.select(:name).distinct
  end

  # GET /users/1
  def show
  end

  # GET /users/1/edit
  def edit
  end

  # PATCH/PUT /users/1
  # PATCH/PUT /users/1.json
  def update
    respond_to do |format|
      if @user.update(user_params)
        format.html { redirect_to @user, notice: 'Your profile was successfully updated.' }
        format.json { render :show, status: :ok, location: @user }
      else
        format.html { render :edit }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @user.destroy
    respond_to do |format|
      format.html { redirect_to users_path, notice: 'USER was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
  def set_user
    @user = User.find(params[:id])
  end

  def auth_hash
    request.env['omniauth.auth']
  end

  def user_params
    params.require(:user).permit(

      :first_name, :last_name, :email, :image_url, :headline, :q1, :q2, :q3, :testamonial,
      :summary, :password, :password_confirmation, :omniauth, :company
    )
  end

  def sort_direction
    ['asc', 'desc'].include?(params[:direction]) ?
      params[:direction] :
      'asc'
  end

  def sort_column
    [User.column_names, 'company_name'].flatten.include?(params[:sort]) ?
      params[:sort] :
      'first_name'
  end

  def verify_current_user
    if current_user == @user
    else
      flash[:error] = 'Not Authorized'
      redirect_to root_path
    end
  end
end
