class CompaniesController < ApplicationController
  before_action :set_company, only: [:show, :edit, :update, :destroy, :claim, :unclaim]
  helper_method :sort_column, :sort_direction

  # GET /companies
  # GET /companies.json
  def index
    if params[:city].present?
      @companies = Company.where(city: params[:city])
    else
      @companies = Company.all
    end

    # add sorting for filtered search
    @companies = @companies.order(sort_column + ' ' + sort_direction)
    @all_companies = Company.select(:city).distinct
  end

  # GET /companies/1
  # GET /companies/1.json
  def show
  end

  # GET /companies/new
  def new
    @company = Company.new
  end

  # GET /companies/1/edit
  def edit
  end

  # POST /companies
  # POST /companies.json
  def create
    @company = Company.new(company_params)

    respond_to do |format|
      if @company.save
        format.html { redirect_to @company, notice: "Company was successfully created. You now work at #{@company.name}." }
        format.json { render :show, status: :created, location: @company }
        if current_user
          @company.users << @current_user
        end
      else
        format.html { render :new }
        format.json { render json: @company.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /companies/1
  # PATCH/PUT /companies/1.json
  def update
    respond_to do |format|
      if @company.update(company_params)
        format.html { redirect_to @company, notice: 'Company was successfully updated.' }
        format.json { render :show, status: :ok, location: @company }
      else
        format.html { render :edit }
        format.json { render json: @company.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /companies/1
  # DELETE /companies/1.json
  def destroy
    @company.destroy
    respond_to do |format|
      format.html { redirect_to companies_url, notice: 'Company was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def claim
    if current_user
      @company.users << @current_user
      redirect_to companies_path, notice: "You now work at #{@company.name}."
    end
  end

  def unclaim
    if @company.users.include?(current_user)
      @company.users.delete(@current_user)
      redirect_to companies_path, notice: "You no longer work at #{@company.name}."
    end
    # if user has already claimed the company, unclaim will make it so
    # they are no longer associated with the company
  end




  private

  def sort_direction
    ['asc', 'desc'].include?(params[:direction]) ?
      params[:direction] :
      'asc'
  end

  def sort_column
    ['name', 'city'].include?(params[:sort]) ?
      params[:sort] :
      'name'
  end

  # Use callbacks to share common setup or constraints between actions.
  def set_company
    @company = Company.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def company_params
    params.require(:company).permit(:name, :city, :company_url)
  end
end
