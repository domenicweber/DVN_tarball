class SessionsController < ApplicationController
  def login
    if current_user
      redirect_to '/companies'
    end
  end



  def oauth
    @user = User.where(
      omniauth: true, email: auth_hash[:info][:email]).first_or_create do |user|
      info = auth_hash[:info]
      first, last = info[:name].split(/\s+/, 2)
      user.first_name = first
      user.last_name = last
      user.image_url = info[:image]
      user.headline = info[:headline]
      user.summary = auth_hash[:extra][:raw_info][:summary]
      # user.company = auth_hash[extra][raw_info][positions][values][0][company][name]
    end
    # Company info:
    #   auth_hash['extra']['raw_info']['positions']['values'][0]['company']['name']
    if @user.valid?
      @user.make_student!


    if @user.persisted?
    session[:id] = @user.id
    redirect_to root_path,
      notice: "Hello #{@user.first_name}"
    else
    @user.needs_verification!
    end
    end
    end



  def create
    user = User.find_by_email(params[:email])
    if user && user.authenticate(params[:password])
      #User provided valid password
      session[:id] = user.id
      redirect_to companies_path,
        notice: "Welcome back #{user.first_name}"
    else
      #User provided invalid password
      flash[:error] = "Invalid email or password"
      render :login
    end
  end

  def destroy
    if user = current_user
      session.delete(:id)
      redirect_to root_path,
        notice: "#{user.email} has been logged out"
    end
  end

  # def oauth
  # client = LinkedIn::Client.new
  # client.authorize_from_access("access_token", "access_token_secret")
  # end

  protected

  def auth_hash
    request.env['omniauth.auth']
  end

end




#
# client.profile
# client.add_share({:comment => "blah"})







#
# class SessionsController < ApplicationController
#   def create
#     @user = User.find_or_create_from_auth_hash(auth_hash)
#     self.current_user = @user
#     redirect_to '/'
#   end
#
#   protected
#
#   def auth_hash
#     request.env['omniauth.auth']
#   end
# end
