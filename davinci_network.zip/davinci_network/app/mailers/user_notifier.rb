class UserNotifier < ApplicationMailer
  default from: 'Domenic Weber <no-reply@davincicoders.com>'

  def signed_up(user)
    @user = user
    mail to: @user.email
  end

  def verified(user)
    @user = user
    mail to: @user.email
  end

  def verify(user)
    @user = user
    mail to: @user.email
  end

  def verification(user)
    @user = user
    mail to: @user.email
  end


end
