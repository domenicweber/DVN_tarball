class ApplicationMailer < ActionMailer::Base
  include SendGrid
  default from: "no-reply@davincicoders.com"
  layout 'mailer'
end
