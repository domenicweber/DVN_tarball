//
//= require flatty/jquery/jquery.min
//= require flatty/jquery/jquery.mobile.custom.min
//= require flatty/jquery/jquery-migrate.min
//= require flatty/jquery/jquery-ui.min
//= require flatty/bootstrap/bootstrap.min
//= require flatty/plugins/plugins
//= require flatty/theme
//= require jquery_ujs
