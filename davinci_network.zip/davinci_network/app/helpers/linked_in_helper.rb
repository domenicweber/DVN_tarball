module LinkedInHelper
end
